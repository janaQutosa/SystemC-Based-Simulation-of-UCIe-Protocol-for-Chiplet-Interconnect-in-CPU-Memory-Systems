#ifndef PACKET_H
#define PACKET_H

#include <systemc.h>
#include <iostream>
#include <vector>

// CXL packet types for memory operations
enum CXLPacketType {
    CXL_MEM_READ,     // Memory read request
    CXL_MEM_WRITE,    // Memory write request
    CXL_SNOOP,        // Cache coherency snoop
    CXL_RESPONSE,     // Response packet
    CXL_CONTROL       // Control/management packet
};

// Standard 256B flit format for CXL
struct Packet {
    // Header fields (16 bytes)
    sc_dt::sc_uint<8> packet_type;    // CXLPacketType
    sc_dt::sc_uint<64> address;       // Memory address
    sc_dt::sc_uint<32> length;        // Transaction length
    sc_dt::sc_uint<24> reserved;      // Reserved fields
    
    // Payload (224 bytes)
    std::vector<sc_dt::sc_uint<8>> payload;
    
    // CRC (16 bits as per UCIe spec)
    sc_dt::sc_uint<16> crc;
    
    // Sequence number for tracking
    sc_dt::sc_uint<8> seq_num;

    Packet() : 
        packet_type(0),
        address(0),
        length(0),
        reserved(0),
        payload(224, 0),  // 224 bytes payload for 256B standard flit
        crc(0),
        seq_num(0) {}

    // Helper methods
    bool isRead() const { return packet_type == CXL_MEM_READ; }
    bool isWrite() const { return packet_type == CXL_MEM_WRITE; }
    bool isSnoop() const { return packet_type == CXL_SNOOP; }
    bool isResponse() const { return packet_type == CXL_RESPONSE; }
    bool isControl() const { return packet_type == CXL_CONTROL; }
};

// Enhanced output operator
inline std::ostream& operator<<(std::ostream& os, const Packet& pkt) {
    os << "CXL Packet {\n"
       << "  Type: ";
    
    switch(pkt.packet_type) {
        case CXL_MEM_READ: os << "Memory Read"; break;
        case CXL_MEM_WRITE: os << "Memory Write"; break;
        case CXL_SNOOP: os << "Cache Snoop"; break;
        case CXL_RESPONSE: os << "Response"; break;
        case CXL_CONTROL: os << "Control"; break;
    }
    
    os << "\n  Address: 0x" << std::hex << pkt.address
       << "\n  Length: " << std::dec << pkt.length
       << "\n  Sequence: " << (int)pkt.seq_num
       << "\n  CRC: 0x" << std::hex << pkt.crc
       << "\n  Payload size: " << std::dec << pkt.payload.size()
       << " bytes\n}";
    return os;
}

#endif // PACKET_H