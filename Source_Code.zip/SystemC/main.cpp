#include <systemc.h>
#include <iomanip>
#include "processor.h"
#include "phy.h"
#include "adapter.h"
#include "protocol.h"
#include "memory.h"

int sc_main(int argc, char* argv[]) {
    sc_report_handler::set_actions(SC_INFO, SC_DISPLAY);
    sc_report_handler::set_actions(SC_WARNING, SC_DISPLAY);
    sc_report_handler::set_actions(SC_ERROR, SC_DISPLAY);
    
    std::cout << "\n=== Starting UCIe CPU-Memory Communication Simulation ===\n\n" << std::flush;

    Processor processor("processor");
    PHY phy1("phy1");
    DieToDieAdapter adapter("adapter");
    ProtocolLayer protocol("protocol");
    Memory memory("memory");

    std::cout << "Modules created successfully\n" << std::flush;

    sc_clock clk("clk", 10, SC_NS);
    sc_signal<bool> reset("reset");

    processor.socket.bind(phy1.target_socket);
    phy1.initiator_socket.bind(adapter.target_socket);
    adapter.init_socket.bind(protocol.fdi_socket);
    protocol.initiator_socket.bind(memory.socket);

    std::cout << "Socket bindings completed\n" << std::flush;

    processor.clk(clk);
    processor.reset(reset);
    phy1.clk(clk);
    phy1.reset(reset);
    adapter.clk(clk);
    adapter.reset(reset);
    protocol.clk(clk);
    protocol.reset(reset);

    std::cout << "\n------------------------------------------------\n\n" << std::flush;

    std::cout << "\nConfiguring modules...\n" << std::flush;

    processor.config.memory_read_ratio = 50;
    processor.config.burst_length = 256;
    processor.config.transaction_rate = 100;
    
    phy1.config.package_type = PHY::UCIeConfig::STANDARD;
    phy1.config.data_rate = PHY::UCIeConfig::GT_16;
    
    adapter.config.replay_mechanism_enabled = false;
    adapter.config.dynamic_multiplexing = true;
    adapter.config.error_detection_enabled = true;
    
    protocol.config.support_256b_flit = true;
    
    memory.config.size = 1024 * 1024 * 1024;
    memory.config.read_latency_ns = 50;
    memory.config.write_latency_ns = 100;

    std::cout << "Module configurations completed\n" << std::flush;

    std::cout << "\n------------------------------------------------\n\n" << std::flush;

    std::cout << "\nApplying reset...\n" << std::flush;
    reset.write(1);
    sc_start(110, SC_NS); // Extended reset to 110ns
    reset.write(0);
    sc_start(10, SC_NS);  // Small delay post-reset
    std::cout << "Reset completed\n" << std::flush;

    std::cout << "\n------------------------------------------------\n\n" << std::flush;

    std::cout << "\nStarting simulation...\n" << std::flush;
    for (int i = 0; i < 30; i++) {
        
        sc_start(100, SC_NS);
        std::cout << "Simulated " << (i+1) * 100 << "ns\n" << std::flush;
        std::cout << "\n------------------\n" << std::flush;

    }

    std::cout << "\n=== UCIe Simulation Results ===\n\n" << std::flush;
    
    std::cout << "CPU Statistics:\n";
    std::cout << "  Reads initiated: " << processor.stats.reads_initiated << "\n";
    std::cout << "  Writes initiated: " << processor.stats.writes_initiated << "\n";
    std::cout << "  Average latency: " << std::fixed << std::setprecision(2) 
              << processor.stats.avg_latency * 1e9 << " ns\n";

    std::cout << "\n------------------------------------------------\n\n" << std::flush;
    
    std::cout << "\nPHY Layer Statistics:\n";
    std::cout << "  Data Rate: " << phy1.config.data_rate << " GT/s\n";
    std::cout << "  Package Type: " << (phy1.config.package_type == PHY::UCIeConfig::STANDARD ? "Standard" : "Advanced") << "\n";
    std::cout << "  Power Target: " << (phy1.config.package_type == PHY::UCIeConfig::STANDARD ? 0.5 : 0.25) << " pJ/bit\n";

    std::cout << "\n------------------------------------------------\n\n" << std::flush;
    
    std::cout << "\nAdapter Layer Statistics:\n";
    std::cout << "  Packets Processed: " << adapter.get_packets_processed() << "\n";
    std::cout << "  CRC Errors: " << adapter.get_crc_errors() << "\n";
    std::cout << "  Retries: " << adapter.get_retries() << "\n";
    std::cout << "  Successful Retries: " << adapter.get_successful_retries() << "\n";
    std::cout << "  Bit Error Rate: " << std::scientific << adapter.get_bit_error_rate() << "\n";

    std::cout << "\n------------------------------------------------\n\n" << std::flush;

    std::cout << "\nProtocol Layer Statistics:\n";
    std::cout << "  Flow Control Stalls: " << protocol.stats.flow_control_stalls << "\n";
    std::cout << "  Total Transactions: " << protocol.stats.total_transactions << "\n";

    std::cout << "\n------------------------------------------------\n\n" << std::flush;

    std::cout << "\nMemory Statistics:\n";
    std::cout << "  Reads completed: " << memory.stats.reads_completed << "\n";
    std::cout << "  Writes completed: " << memory.stats.writes_completed << "\n";
    std::cout << "  Average read latency: " << std::fixed << std::setprecision(2) 
              << memory.stats.avg_read_latency * 1e9 << " ns\n";
    std::cout << "  Average write latency: " << std::fixed << std::setprecision(2) 
              << memory.stats.avg_write_latency * 1e9 << " ns\n\n";

    std::cout << "\n=== UCIe Simulation Complete ===\n\n\n" << std::flush;
    return 0;
}