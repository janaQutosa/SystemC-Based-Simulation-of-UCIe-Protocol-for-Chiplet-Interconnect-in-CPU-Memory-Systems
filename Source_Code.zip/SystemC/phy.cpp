#include "phy.h"
#include <iostream>

PHY::PHY(sc_module_name name) : 
    sc_module(name),
    target_socket("target_socket"),
    initiator_socket("initiator_socket"),
    clk("clk"),
    reset("reset"),
    current_state(RESET),
    training_cycles(0),
    scrambling_enabled(true),
    forward_clock_gated(false),
    last_activity(sc_time_stamp()),
    last_margin_check(sc_time_stamp()),
    margin_check_interval(sc_time(1000, SC_NS)) {
    
    target_socket.register_b_transport(this, &PHY::b_transport);
    
    modules.resize(config.num_modules);
    for(size_t i = 0; i < modules.size(); i++) {
        modules[i].module_id = i;
        modules[i].data_lanes.resize(config.lanes_per_module);
    }
    
    lane_status.resize(config.total_lanes);
    
    SC_THREAD(phy_state_machine);
    sensitive << clk.pos();
    
    SC_THREAD(lane_monitoring);
    sensitive << clk.pos();
    
    SC_THREAD(power_management);
    sensitive << clk.pos();
}

void PHY::b_transport(tlm::tlm_generic_payload& trans, sc_core::sc_time& delay) {
    
    std::cout << sc_time_stamp() << " [PHY]: Accumulated delay = " << delay << std::endl;
    PacketExtension* ext = nullptr;
    trans.get_extension(ext);
    
    std::cout << sc_time_stamp() << " PHY: Received transaction, ext: " 
              << (ext ? "valid" : "null") << ", addr: 0x" 
              << std::hex << (ext ? ext->pkt.address : sc_dt::sc_uint<64>(0)) << std::dec << "\n";
    
    if (!ext) {
        trans.set_response_status(tlm::TLM_GENERIC_ERROR_RESPONSE);
        return;
    }

    if (current_state == ERROR_RECOVERY) {
        trans.set_response_status(tlm::TLM_GENERIC_ERROR_RESPONSE);
        std::cout << sc_time_stamp() << " PHY: Transaction rejected due to error recovery\n";
        return;
    }

    if (config.package_type == UCIeConfig::ADVANCED) {
        handle_advanced_package_transfer(trans);
    } else {
        handle_standard_package_transfer(trans);
    }


    sc_time phy_delay(5, SC_NS); // Add 5 ns processing delay
    delay += phy_delay;
    wait(phy_delay); 
    
    initiator_socket->b_transport(trans, delay);
    last_activity = sc_time_stamp();


}

void PHY::phy_state_machine() {
    while (true) {
        wait(clk->posedge_event());
        
        if (reset.read()) {
            current_state = RESET;
            continue;
        }

        switch (current_state) {
            case RESET:
                current_state = TRAINING;
                training_cycles = 0;
                break;
            case TRAINING:
                training_cycles++;
                if (check_voltage_margins() && check_timing_margins()) {
                    if (training_cycles >= 10) {
                        current_state = ACTIVE;
                        std::cout << sc_time_stamp() << " PHY: Training complete\n";
                    }
                }
                break;
            case ACTIVE:
                if (!check_voltage_margins() || !check_timing_margins()) {
                    current_state = ERROR_RECOVERY;
                    std::cout << sc_time_stamp() << " PHY: Entering error recovery\n";
                }
                break;
            case ERROR_RECOVERY:
                perform_lane_repair();
                if (count_operational_lanes() >= config.min_lanes) {
                    current_state = TRAINING;
                    std::cout << sc_time_stamp() << " PHY: Returning to training\n";
                } else {
                    width_degradation();
                    if (count_operational_lanes() < config.min_lanes) {
                        SC_REPORT_FATAL("PHY", "Critical failure: Insufficient operational lanes");
                    }
                }
                break;
            default:
                break;
        }
    }
}

bool PHY::check_voltage_margins() {
    bool all_margins_ok = true;
    for (size_t i = 0; i < lane_status.size(); i++) {
        if (lane_status[i].active && !lane_status[i].is_spare) {
            if (lane_status[i].voltage_margin < config.min_voltage_margin) {
                handle_margin_violation(i);
                all_margins_ok = false;
            }
        }
    }
    return all_margins_ok;
}

bool PHY::check_timing_margins() {
    bool all_margins_ok = true;
    for (size_t i = 0; i < lane_status.size(); i++) {
        if (lane_status[i].active && !lane_status[i].is_spare) {
            if (lane_status[i].timing_margin < config.min_timing_margin) {
                handle_margin_violation(i);
                all_margins_ok = false;
            }
        }
    }
    return all_margins_ok;
}

void PHY::perform_lane_repair() {
    std::cout << sc_time_stamp() << " PHY: Attempting lane repair\n";
    stats.lane_repairs++;
    
    bool repair_successful = false;
    for (size_t i = 0; i < lane_status.size(); i++) {
        if (!lane_status[i].operational && lane_status[i].is_spare) {
            lane_status[i].is_spare = false;
            lane_status[i].operational = true;
            lane_status[i].voltage_margin = config.nominal_voltage_margin;
            lane_status[i].timing_margin = config.nominal_timing_margin;
            repair_successful = true;
            break;
        }
    }
    
    if (!repair_successful) {
        std::cout << sc_time_stamp() << " PHY: No spare lanes available for repair\n";
    }
}

void PHY::width_degradation() {
    std::cout << sc_time_stamp() << " PHY: Performing width degradation\n";
    stats.width_degradations++;
    
    config.active_lanes = std::max(config.active_lanes / 2, config.min_lanes);
    
    for (size_t i = lane_status.size(); i > config.active_lanes; --i) {
        if (!lane_status[i-1].is_spare) {
            lane_status[i-1].active = false;
            lane_status[i-1].operational = false;
        }
    }
    
    std::cout << sc_time_stamp() 
              << " PHY: Width degraded to " << config.active_lanes 
              << " lanes\n";
}

void PHY::handle_advanced_package_transfer(tlm::tlm_generic_payload& trans) {
    for (auto& module : modules) {
        if (!module.initialized) {
            std::cout << sc_core::sc_time_stamp() 
                      << " PHY: Module " << module.module_id 
                      << " not initialized\n";
            return;
        }
    }
}

void PHY::handle_standard_package_transfer(tlm::tlm_generic_payload& trans) {
    if (config.total_lanes != UCIeConfig::STD_PACKAGE_LANES) {
        std::cout << sc_core::sc_time_stamp() 
                  << " PHY: Invalid lane configuration for standard package\n";
        return;
    }
}

void PHY::parameter_exchange() {
    sideband.negotiated_params.clear();
    
    sideband.negotiated_params["data_rate"] = config.data_rate;
    sideband.negotiated_params["num_lanes"] = config.total_lanes;
    sideband.negotiated_params["package_type"] = config.package_type;
    
    sideband.negotiated_params["lane_reversal"] = config.lane_reversal_support;
    sideband.negotiated_params["dynamic_clock_gating"] = config.dynamic_clock_gating;
    sideband.negotiated_params["scrambling"] = config.scrambling_enabled;
    
    if (stats.eye_margins_per_lane.size() > 0) {
        sideband.negotiated_params["automotive_support"] = 1;
    }
    
    validate_configuration();
    sideband.parameter_exchange_done = true;
}

void PHY::validate_configuration() {
    if (config.package_type == UCIeConfig::ADVANCED) {
        if (config.total_lanes != UCIeConfig::ADV_PACKAGE_LANES_32 && 
            config.total_lanes != UCIeConfig::ADV_PACKAGE_LANES_64) {
            SC_REPORT_FATAL("PHY", "Invalid lane configuration for advanced package");
        }
    } else {
        if (config.total_lanes != UCIeConfig::STD_PACKAGE_LANES) {
            SC_REPORT_FATAL("PHY", "Invalid lane configuration for standard package");
        }
    }
}

void PHY::lane_monitoring() {
    while (true) {
        wait(clk->posedge_event());
        
        sc_time current_time = sc_time_stamp();
        if (current_time - last_margin_check >= margin_check_interval) {
            if (current_state == ACTIVE) {
                monitor_eye_margins();
                check_voltage_margins();
                check_timing_margins();
                last_margin_check = current_time;
            }
        }
    }
}

void PHY::monitor_eye_margins() {
    for (size_t i = 0; i < lane_status.size(); i++) {
        if (lane_status[i].active) {
            lane_status[i].eye_margin = calculate_eye_margin(i);
            if (lane_status[i].eye_margin < 0.4) {
                stats.margin_violations++;
                handle_margin_violation(i);
            }
        }
    }
}

double PHY::calculate_eye_margin(int lane_id) {
    return 1.0; 
}

void PHY::handle_margin_violation(int lane_id) {
    if (config.package_type == UCIeConfig::ADVANCED) {
        if (stats.lane_repairs < 2) {
            perform_lane_repair();
        }
    } else {
        width_degradation();
    }
}

void PHY::power_management() {
    while (true) {
        wait(sc_core::sc_time(100, sc_core::SC_NS));
        
        if (current_state == ACTIVE) {
            sc_core::sc_time idle_time = sc_core::sc_time_stamp() - last_activity;
            
            if (idle_time > sc_core::sc_time(1, sc_core::SC_US)) {
                enter_power_save_state(L1_POWER_SAVE);
            } else if (idle_time > sc_core::sc_time(10, sc_core::SC_US)) {
                enter_power_save_state(L2_POWER_SAVE);
            }
        }
    }
}

void PHY::enter_power_save_state(LinkState state) {
    current_state = state;
    if (state == L1_POWER_SAVE) {
        forward_clock_gated = true;
    } else if (state == L2_POWER_SAVE) {
        power_down_lanes();
    }
}

void PHY::power_down_lanes() {
    for (auto& lane : lane_status) {
        if (lane.active) {
            lane.active = false;
        }
    }
}

void PHY::handle_forwarded_clock() {
    if (current_state == L0_STATE && config.dynamic_clock_gating) {
        sc_core::sc_time entry_time = sc_core::sc_time(0.5, sc_core::SC_NS);
        if (config.data_rate >= UCIeConfig::GT_24) {
            entry_time = sc_core::sc_time(1.0, sc_core::SC_NS);
        }
        wait(entry_time);
    }
}

void PHY::perform_runtime_test() {
    if (!config.automotive_features) return;
    
    check_eye_margin_registers();
    perform_parity_injection();
    stats.runtime_tests_completed++;
}

void PHY::check_eye_margin_registers() {
    for (size_t i = 0; i < config.total_lanes; i++) {
        if (lane_status[i].active) {
            control_registers[0x100 + i] = static_cast<uint32_t>(lane_status[i].eye_margin * 1000);
        }
    }
}

void PHY::perform_parity_injection() {
    static int test_lane = 0;
    
    if (test_lane < config.total_lanes) {
        inject_parity_error(test_lane);
        test_lane++;
    } else {
        test_lane = 0;
    }
}

void PHY::inject_parity_error(int lane_id) {
    if (!lane_status[lane_id].active) return;
    
    std::cout << sc_core::sc_time_stamp() 
              << " PHY: Injecting parity error on lane " << lane_id 
              << " for testing\n";
    
    lane_status[lane_id].error_count++;
}

void PHY::check_package_compatibility() {
    if (config.package_type == UCIeConfig::ADVANCED) {
        bool valid = (config.total_lanes == UCIeConfig::ADV_PACKAGE_LANES_32) || 
                    (config.total_lanes == UCIeConfig::ADV_PACKAGE_LANES_64);
        
        if (!valid) {
            SC_REPORT_FATAL("PHY", "Invalid advanced package lane configuration");
        }
    } else {
        if (config.total_lanes != UCIeConfig::STD_PACKAGE_LANES) {
            SC_REPORT_FATAL("PHY", "Invalid standard package lane configuration");
        }
    }
}

void PHY::verify_lane_configuration() {
    if (config.num_modules < 1 || config.num_modules > 4) {
        SC_REPORT_FATAL("PHY", "Invalid number of modules");
    }
    
    for (const auto& module : modules) {
        if (module.data_lanes.size() != static_cast<size_t>(config.lanes_per_module)) {
            SC_REPORT_FATAL("PHY", "Invalid module lane configuration");
        }
    }
}

void PHY::setup_spare_lanes() {
    if (config.package_type == UCIeConfig::ADVANCED) {
        config.spare_lanes = (config.total_lanes / 32) * 2;
        
        for (int i = 0; i < config.spare_lanes; i++) {
            size_t lane_idx = config.total_lanes - i - 1;
            if (lane_idx < lane_status.size()) {
                lane_status[lane_idx].is_spare = true;
                lane_status[lane_idx].active = false;
            }
        }
    }
}

double PHY::calculate_power_consumption() {
    double power = 0.0;
    
    double target = (config.package_type == UCIeConfig::ADVANCED) ? 
                   config.POWER_TARGET_ADV_mW / 1000.0 : 
                   config.POWER_TARGET_STD_mW / 1000.0;
    
    int active_lane_count = 0;
    for (const auto& lane : lane_status) {
        if (lane.active && !lane.is_spare) active_lane_count++;
    }
    
    power = active_lane_count * target * config.data_rate;
    
    if (forward_clock_gated) {
        power *= 0.6;
    }
    
    return power;
}

int PHY::count_operational_lanes() const {
    int count = 0;
    for (const auto& lane : lane_status) {
        if (lane.operational && !lane.is_spare) {
            count++;
        }
    }
    return count;
}