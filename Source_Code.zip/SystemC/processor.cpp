#include "processor.h"
#include <iostream>
#include <random>

Processor::Processor(sc_module_name name) : 
    sc_module(name),
    socket("socket"),
    clk("clk"),
    reset("reset")
{
    SC_THREAD(generate_transactions);
    sensitive << clk.pos();
    
    SC_THREAD(monitor_performance);
    sensitive << clk.pos();
}

void Processor::generate_transactions() {
    while (true) {
        wait(clk->posedge_event());
        if (reset.read()) continue;
        static int cycle_count = 0;
        if (cycle_count >= 12 && cycle_count % 10 == 0) { // Start at 120ns
            uint64_t address = generate_address();
            uint32_t length = generate_burst_length();
            if ((rand() % 100) < config.memory_read_ratio) {
                send_memory_read(address, length);
                stats.reads_initiated++;
            } else {
                std::vector<uint8_t> data = generate_data(length);
                send_memory_write(address, data);
                stats.writes_initiated++;
            }
        }
        cycle_count++;
    }
}

void Processor::monitor_performance() {
    while (true) {
        wait(clk->posedge_event());
        wait(1000, SC_NS);
        std::cout << sc_time_stamp() 
                  << " Processor Monitor: "
                  << "\n  Reads initiated: " << stats.reads_initiated
                  << "\n  Writes initiated: " << stats.writes_initiated
                  << "\n  Transactions completed: " << stats.transactions_completed
                  << "\n  Average latency: " << stats.avg_latency * 1e9 << " ns\n";
    }
}

void Processor::send_memory_read(uint64_t address, uint32_t length) {
    stats.transactions_initiated++; 

    tlm::tlm_generic_payload* trans = new tlm::tlm_generic_payload;
    PacketExtension* ext = new PacketExtension;
    sc_time delay = sc_time(0, SC_NS);
    
    ext->pkt.packet_type = CXL_MEM_READ;
    ext->pkt.address = address;
    ext->pkt.length = length;
    ext->pkt.payload.resize(length, 0);
    ext->pkt.seq_num = stats.transactions_initiated; 
    ext->pkt.crc = calculate_crc(ext->pkt);
    
    trans->set_command(tlm::TLM_READ_COMMAND);
    trans->set_address(address);
    trans->set_data_length(length);
    trans->set_streaming_width(length);
    trans->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE);
    trans->set_extension(ext);
    
    ext->start_time = sc_time_stamp();
    ext->is_memory_read = true;
    ext->transaction_id = stats.transactions_initiated; 

    std::cout << sc_time_stamp() << " Processor: Sending read transaction, addr: 0x" 
              << std::hex << address << std::dec << ", len: " << length << "\n";
    
    socket->b_transport(*trans, delay);
    wait(delay); 
    
    if (trans->get_response_status() == tlm::TLM_OK_RESPONSE) {
        log_transaction(ext);
        update_statistics(ext);
    } else {
        std::cout << sc_time_stamp() << " Processor: Read transaction failed, addr: 0x"
                  << std::hex << address << std::dec << "\n";
    }
    
    delete ext; 
    delete trans;
}

void Processor::send_memory_write(uint64_t address, const std::vector<uint8_t>& data) {
    if (data.size() == 0 || data.size() > config.burst_length) {
        std::cout << sc_time_stamp() << " Processor: Invalid data size: " << data.size() << "\n";
        return;
    }

    stats.transactions_initiated++; 

    tlm::tlm_generic_payload* trans = new tlm::tlm_generic_payload;
    PacketExtension* ext = new PacketExtension;
    sc_time delay = sc_time(0, SC_NS);
    
    unsigned char* data_ptr = new unsigned char[data.size()];
    std::copy(data.begin(), data.end(), data_ptr);
    
    ext->pkt.packet_type = CXL_MEM_WRITE;
    ext->pkt.address = address;
    ext->pkt.length = data.size();
    ext->pkt.payload.resize(data.size());
    for (size_t i = 0; i < data.size(); i++) {
        ext->pkt.payload[i] = data[i];
    }
    ext->pkt.seq_num = stats.transactions_initiated; 
    ext->pkt.crc = calculate_crc(ext->pkt);
    
    trans->set_command(tlm::TLM_WRITE_COMMAND);
    trans->set_address(address);
    trans->set_data_ptr(data_ptr);
    trans->set_data_length(data.size());
    trans->set_streaming_width(data.size());
    trans->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE);
    trans->set_extension(ext);
    
    ext->start_time = sc_time_stamp();
    ext->is_memory_write = true;
    ext->transaction_id = stats.transactions_initiated; 
    
    std::cout << sc_time_stamp() << " Processor: Sending write transaction, addr: 0x" 
              << std::hex << address << std::dec << ", len: " << data.size() << "\n";
    
    socket->b_transport(*trans, delay);
    wait(delay); 
    
    if (trans->get_response_status() == tlm::TLM_OK_RESPONSE) {
        log_transaction(ext);
        update_statistics(ext);
    } else {
        std::cout << sc_time_stamp() << " Processor: Write transaction failed, addr: 0x"
                  << std::hex << address << std::dec << "\n";
    }
    
    delete ext; 
    delete[] data_ptr;
    delete trans;
}
uint64_t Processor::generate_address() {
    static uint64_t next_address = 0x1000;
    uint64_t max_address = 1024 * 1024 * 1024;
    config.random_addresses = false;
    uint64_t address = next_address;
    next_address = (next_address + config.burst_length) % max_address;
    return address;
}

uint32_t Processor::generate_burst_length() {
    return config.burst_length;
}

std::vector<uint8_t> Processor::generate_data(uint32_t size) {
    std::vector<uint8_t> data(size);
    for (uint32_t i = 0; i < size; i++) {
        data[i] = static_cast<uint8_t>(i % 256);
    }
    return data;
}

void Processor::log_transaction(const PacketExtension* ext) {
    std::cout << sc_time_stamp() 
              << " Processor: " << (ext->is_memory_read ? "Read" : "Write")
              << " transaction completed at address 0x"
              << std::hex << ext->pkt.address << std::dec << "\n";
}

void Processor::update_statistics(const PacketExtension* ext) {
    stats.transactions_completed++;
    stats.update_latency(sc_time_stamp() - ext->start_time);
    log_transaction(ext);
}

uint16_t Processor::calculate_crc(const Packet& pkt) {
    uint16_t crc = 0xFFFF;
    auto process_byte = [&crc](uint8_t byte) {
        crc ^= (byte << 8);
        for (int i = 0; i < 8; i++) {
            crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) : (crc << 1);
        }
    };
    
    process_byte(pkt.packet_type.to_uint());
    for (int i = 0; i < 8; i++) {
        process_byte((pkt.address >> (i * 8)) & 0xFF);
    }
    for (int i = 0; i < 4; i++) {
        process_byte((pkt.length >> (i * 8)) & 0xFF);
    }
    
    for (const auto& byte : pkt.payload) {
        process_byte(byte.to_uint());
    }
    
    return crc;
}