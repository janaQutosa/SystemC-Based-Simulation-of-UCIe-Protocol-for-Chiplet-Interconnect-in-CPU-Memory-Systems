#ifndef PROTOCOL_H
#define PROTOCOL_H

#include <systemc.h>
#include <tlm_utils/simple_target_socket.h>
#include <tlm_utils/simple_initiator_socket.h>
#include "packet.h"
#include "packet_extension.h"

// UCIe Protocol Layer Module
SC_MODULE(ProtocolLayer) {
    // TLM sockets
    tlm_utils::simple_target_socket<ProtocolLayer> fdi_socket;        // From adapter layer
    tlm_utils::simple_initiator_socket<ProtocolLayer> initiator_socket; // To memory

    // Clock and control
    sc_in<bool> clk;
    sc_in<bool> reset;

    // Protocol configuration
    struct ProtocolConfig {
        bool support_256b_flit;      // Standard 256B flit support
        uint32_t max_payload_size;   // Maximum payload size
        bool flow_control_enabled;   // Flow control support
        
        ProtocolConfig() :
            support_256b_flit(true),
            max_payload_size(256),
            flow_control_enabled(true) {}
    } config;

    // Protocol statistics
    struct Stats {

         sc_core::sc_time total_latency = sc_core::SC_ZERO_TIME;
  
        uint64_t reads_processed;
        uint64_t writes_processed;
        uint64_t flow_control_stalls;
        double avg_latency = 0.0; // Average latency in seconds
        sc_time total_processing_time;
        uint64_t total_transactions;

        Stats() :
            reads_processed(0),
            writes_processed(0),
            flow_control_stalls(0),
            avg_latency(0),
            total_processing_time(sc_core::SC_ZERO_TIME),
            total_transactions(0) {}

        void update_latency(sc_time transaction_time) {
            total_processing_time += transaction_time;
            total_transactions++;
            avg_latency = total_processing_time.to_seconds() / total_transactions;
        }
    } stats;

    SC_HAS_PROCESS(ProtocolLayer);
    ProtocolLayer(sc_module_name name) : 
        sc_module(name),
        fdi_socket("fdi_socket"),
        initiator_socket("initiator_socket") 
    {
        // Register callbacks
        fdi_socket.register_b_transport(this, &ProtocolLayer::b_transport);

        // Register processes
        SC_THREAD(protocol_monitor);
        sensitive << clk.pos();
    }

    // TLM interface methods
    void b_transport(tlm::tlm_generic_payload& trans, sc_core::sc_time& delay);

private:
    // Protocol processing methods
   void process_memory_read(PacketExtension* ext, sc_core::sc_time& delay, tlm::tlm_generic_payload& parent_trans);
   void process_memory_write(PacketExtension* ext, sc_core::sc_time& delay, tlm::tlm_generic_payload& parent_trans);
    bool validate_transaction(const PacketExtension* ext);
    
    // Flow control
    bool check_flow_control();
    void update_flow_control_credits();
    
    // Monitoring and statistics
    void protocol_monitor();
    void log_transaction(const PacketExtension* ext);
    void update_statistics(const PacketExtension* ext);

    // Error handling
    void handle_protocol_error(PacketExtension* ext);
    bool recover_from_error();
};

#endif // PROTOCOL_H