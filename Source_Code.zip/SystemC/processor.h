#ifndef PROCESSOR_H
#define PROCESSOR_H

#include <systemc.h>
#include <tlm.h>
#include <tlm_utils/simple_initiator_socket.h>
#include <vector>
#include "packet.h"
#include "packet_extension.h"

SC_MODULE(Processor) {
    // TLM socket for memory transactions
    tlm_utils::simple_initiator_socket<Processor> socket;

    // Clock and control
    sc_in<bool> clk;
    sc_in<bool> reset;

    // Processor configuration
    struct ProcessorConfig {
        uint32_t memory_read_ratio;     // Percentage of read operations
        uint32_t burst_length;          // Maximum burst length
        uint32_t transaction_rate;      // Transactions per cycle
        bool random_addresses;          // Random or sequential addressing

        ProcessorConfig() : 
            memory_read_ratio(70),      // 70% reads, 30% writes
            burst_length(256),          // Max 256B per UCIe flit
            transaction_rate(1),        // 1 transaction per cycle
            random_addresses(true) {}
    } config;

    // Performance statistics
    struct Stats {
        unsigned transactions_initiated = 0;
        uint64_t reads_initiated;
        uint64_t writes_initiated;
        uint64_t transactions_completed;
        double avg_latency;
        sc_time total_active_time;

        Stats() : 
            reads_initiated(0),
            writes_initiated(0),
            transactions_completed(0),
            avg_latency(0) {}

        void update_latency(sc_time transaction_time) {
            avg_latency = ((avg_latency * transactions_completed) + 
                          transaction_time.to_seconds()) / (transactions_completed + 1);
            transactions_completed++;
        }
    } stats;

    // Constructor
    SC_CTOR(Processor);

private:
    // Transaction generation
    void generate_transactions();
    void send_memory_read(uint64_t address, uint32_t length);
    void send_memory_write(uint64_t address, const std::vector<uint8_t>& data);
    
    // Helper methods
    uint64_t generate_address();
    uint32_t generate_burst_length();
    std::vector<uint8_t> generate_data(uint32_t size);
    
    // Monitoring and statistics
    void monitor_performance();
    void log_transaction(const PacketExtension* ext);
    void update_statistics(const PacketExtension* ext);
    
    // CRC calculation for packet validation
    uint16_t calculate_crc(const Packet& pkt);
};

#endif // PROCESSOR_H